// Dashboard JavaScript
document.addEventListener('DOMContentLoaded', () => {
    // Check authentication
    checkAuth();
    
    // Initialize dashboard
    initializeDashboard();
    
    // Load user data
    loadUserData();
    
    // Initialize video management
    initializeVideoManagement();
    
    // Initialize sidebar
    initializeSidebar();
    
    // Initialize user menu
    initializeUserMenu();
});

// Authentication check
function checkAuth() {
    const token = localStorage.getItem('authToken');
    if (!token) {
        window.location.href = 'login.html';
        return;
    }
    
    // Verify token with backend
    fetch('/api/auth/verify', {
        headers: {
            'Authorization': `Bearer ${token}`
        }
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Token invalid');
        }
        return response.json();
    })
    .catch(() => {
        localStorage.removeItem('authToken');
        window.location.href = 'login.html';
    });
}

// Initialize dashboard
function initializeDashboard() {
    // Load stats
    loadDashboardStats();
    
    // Load recent activity
    loadRecentActivity();
    
    // Check subscription status
    checkSubscriptionStatus();
}

// Load user data
async function loadUserData() {
    try {
        const token = localStorage.getItem('authToken');
        const response = await fetch('/api/user/profile', {
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });
        
        if (response.ok) {
            const userData = await response.json();
            document.getElementById('userName').textContent = userData.name || userData.username;
        }
    } catch (error) {
        console.error('Error loading user data:', error);
    }
}

// Load dashboard stats
async function loadDashboardStats() {
    try {
        const token = localStorage.getItem('authToken');
        const response = await fetch('/api/dashboard/stats', {
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });
        
        if (response.ok) {
            const stats = await response.json();
            document.getElementById('totalVideos').textContent = stats.totalVideos || 0;
            document.getElementById('totalPosts').textContent = stats.totalPosts || 0;
            document.getElementById('scheduledPosts').textContent = stats.scheduledPosts || 0;
            document.getElementById('totalViews').textContent = formatNumber(stats.totalViews || 0);
        }
    } catch (error) {
        console.error('Error loading stats:', error);
    }
}

// Check subscription status
async function checkSubscriptionStatus() {
    try {
        const token = localStorage.getItem('authToken');
        const response = await fetch('/api/subscription/status', {
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });
        
        if (response.ok) {
            const subscription = await response.json();
            updateSubscriptionUI(subscription);
        }
    } catch (error) {
        console.error('Error checking subscription:', error);
    }
}

// Update subscription UI
function updateSubscriptionUI(subscription) {
    const container = document.getElementById('subscription-status');
    
    if (subscription.active) {
        container.innerHTML = `
            <div class="text-center">
                <i class="fas fa-check-circle text-green-500 text-3xl mb-2"></i>
                <p class="font-semibold text-gray-900">${subscription.plan_name}</p>
                <p class="text-sm text-gray-600">Expira em ${formatDate(subscription.expires_at)}</p>
                <div class="mt-3">
                    <a href="subscription.html" class="text-sm text-indigo-600 hover:text-indigo-500">
                        Gerenciar assinatura →
                    </a>
                </div>
            </div>
        `;
    } else {
        container.innerHTML = `
            <div class="text-center py-4">
                <i class="fas fa-exclamation-triangle text-yellow-500 text-3xl mb-2"></i>
                <p class="text-gray-600 mb-4">Você não possui uma assinatura ativa</p>
                <a href="subscription.html" class="btn bg-yellow-500 text-white font-semibold py-2 px-4 rounded-lg hover:bg-yellow-600">
                    Assinar Agora
                </a>
            </div>
        `;
    }
}

// Initialize video management
function initializeVideoManagement() {
    const videoTitleInput = document.getElementById('videoTitleInput');
    const videoDescInput = document.getElementById('videoDescInput');
    const videoFileInput = document.getElementById('videoFileInput');
    const fileNameSpan = document.getElementById('fileName');
    const addVideoBtn = document.getElementById('addVideoBtn');
    const planningContainer = document.getElementById('planning-container');
    const socialAccountsContainer = document.getElementById('social-accounts');
    const scheduledPostsContainer = document.getElementById('scheduled-posts-container');

    // Modal elements
    const scheduleModal = document.getElementById('scheduleModal');
    const modalVideoTitle = document.getElementById('modalVideoTitle');
    const cancelScheduleBtn = document.getElementById('cancelScheduleBtn');
    const confirmScheduleBtn = document.getElementById('confirmScheduleBtn');
    const scheduleVideoIdInput = document.getElementById('scheduleVideoId');
    const scheduleDateInput = document.getElementById('scheduleDate');
    const scheduleTimeInput = document.getElementById('scheduleTime');
    const modalSocialPlatformsContainer = document.getElementById('modal-social-platforms');

    // Estado da aplicação
    const state = {
        plannedVideos: JSON.parse(localStorage.getItem('plannedVideos') || '[]'),
        scheduledPosts: JSON.parse(localStorage.getItem('scheduledPosts') || '[]'),
        socials: [
            { id: 'youtube', name: 'YouTube', icon: 'fab fa-youtube', color: 'text-red-600', connected: false },
            { id: 'instagram', name: 'Instagram', icon: 'fab fa-instagram', color: 'text-pink-500', connected: false },
            { id: 'tiktok', name: 'TikTok', icon: 'fab fa-tiktok', color: 'text-black', connected: false },
            { id: 'facebook', name: 'Facebook', icon: 'fab fa-facebook', color: 'text-blue-800', connected: false },
        ]
    };

    // Load social connections
    loadSocialConnections();

    // File input change handler
    videoFileInput.addEventListener('change', (event) => {
        fileNameSpan.textContent = event.target.files[0] ? event.target.files[0].name : 'Nenhum arquivo selecionado.';
    });

    // Add video button handler
    addVideoBtn.addEventListener('click', addVideoToList);

    // Schedule button handler
    planningContainer.addEventListener('click', (event) => {
        if (event.target.classList.contains('schedule-btn') || event.target.closest('.schedule-btn')) {
            const btn = event.target.classList.contains('schedule-btn') ? event.target : event.target.closest('.schedule-btn');
            const videoId = btn.dataset.videoId;
            openScheduleModal(videoId);
        }
    });

    // Modal handlers
    cancelScheduleBtn.addEventListener('click', closeScheduleModal);
    confirmScheduleBtn.addEventListener('click', confirmSchedule);

    // Social connect handlers
    socialAccountsContainer.addEventListener('click', (event) => {
        if (event.target.classList.contains('connect-btn') || event.target.closest('.connect-btn')) {
            const btn = event.target.classList.contains('connect-btn') ? event.target : event.target.closest('.connect-btn');
            const socialId = btn.dataset.socialId;
            handleConnectSocial(socialId);
        }
    });

    // Functions
    async function addVideoToList() {
        const title = videoTitleInput.value.trim();
        const description = videoDescInput.value.trim();
        const file = videoFileInput.files[0];

        if (!title || !description || !file) {
            showNotification('Por favor, preencha todos os campos e selecione um arquivo de vídeo.', 'error');
            return;
        }

        // Check subscription
        const hasSubscription = await checkActiveSubscription();
        if (!hasSubscription) {
            showNotification('Você precisa de uma assinatura ativa para fazer upload de vídeos.', 'error');
            return;
        }

        const newVideo = {
            id: Date.now(),
            title,
            description,
            file: {
                name: file.name,
                size: file.size,
                type: file.type
            },
            status: 'planned',
            createdAt: new Date().toISOString()
        };

        // Upload video to backend
        try {
            const formData = new FormData();
            formData.append('video', file);
            formData.append('title', title);
            formData.append('description', description);

            const token = localStorage.getItem('authToken');
            const response = await fetch('/api/videos/upload', {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${token}`
                },
                body: formData
            });

            if (response.ok) {
                const result = await response.json();
                newVideo.id = result.video.id;
                
                state.plannedVideos.push(newVideo);
                localStorage.setItem('plannedVideos', JSON.stringify(state.plannedVideos));
                renderPlannedVideos();

                // Reset form
                videoTitleInput.value = '';
                videoDescInput.value = '';
                videoFileInput.value = '';
                fileNameSpan.textContent = 'Nenhum arquivo selecionado.';

                showNotification('Vídeo adicionado com sucesso!', 'success');
            } else {
                throw new Error('Erro no upload');
            }
        } catch (error) {
            showNotification('Erro ao fazer upload do vídeo. Tente novamente.', 'error');
        }
    }

    function renderSocialAccounts() {
        socialAccountsContainer.innerHTML = '';
        state.socials.forEach(social => {
            const isConnected = social.connected;
            const accountDiv = document.createElement('div');
            accountDiv.className = 'flex items-center justify-between p-3 rounded-lg';
            accountDiv.innerHTML = `
                <div class="flex items-center">
                    <i class="${social.icon} ${social.color} text-2xl mr-4"></i>
                    <span class="font-semibold">${social.name}</span>
                </div>
                <button data-social-id="${social.id}" class="connect-btn btn text-sm font-semibold py-1 px-3 rounded-full ${isConnected ? 'bg-green-100 text-green-800 cursor-default' : 'bg-blue-100 text-blue-800 hover:bg-blue-200'}">
                    ${isConnected ? 'Conectado' : 'Conectar'}
                </button>
            `;
            socialAccountsContainer.appendChild(accountDiv);
        });
    }

    function renderPlannedVideos() {
        if (state.plannedVideos.length === 0) {
            planningContainer.innerHTML = '<p class="text-gray-500">Seus vídeos planejados aparecerão aqui...</p>';
            return;
        }
        planningContainer.innerHTML = '';
        state.plannedVideos.forEach(video => {
            const videoCard = document.createElement('div');
            videoCard.className = 'p-4 border border-gray-200 rounded-lg flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4';
            videoCard.innerHTML = `
                <div>
                    <h4 class="font-bold text-lg">${video.title}</h4>
                    <p class="text-gray-600 text-sm">${video.description}</p>
                    <p class="text-gray-500 text-xs mt-2"><i class="fas fa-file-video mr-1"></i>${video.file.name}</p>
                    <div class="flex items-center mt-2 space-x-4">
                        <span class="text-xs text-gray-500">
                            <i class="fas fa-calendar mr-1"></i>${formatDate(video.createdAt)}
                        </span>
                        <span class="text-xs px-2 py-1 bg-blue-100 text-blue-800 rounded-full">
                            ${video.status}
                        </span>
                    </div>
                </div>
                <div class="flex space-x-2">
                    <button data-video-id="${video.id}" class="process-btn btn bg-purple-500 text-white font-semibold py-2 px-4 rounded-lg hover:bg-purple-600 text-sm">
                        <i class="fas fa-cogs mr-2"></i>Processar IA
                    </button>
                    <button data-video-id="${video.id}" class="schedule-btn btn bg-indigo-500 text-white font-semibold py-2 px-4 rounded-lg hover:bg-indigo-600 text-sm">
                        <i class="fas fa-calendar-plus mr-2"></i>Agendar
                    </button>
                </div>
            `;
            planningContainer.appendChild(videoCard);
        });
    }

    function renderScheduledPosts() {
        if (state.scheduledPosts.length === 0) {
            scheduledPostsContainer.innerHTML = '<p class="text-gray-500">Nenhum post agendado ainda.</p>';
            return;
        }
        scheduledPostsContainer.innerHTML = '';
        state.scheduledPosts.forEach(post => {
            const postDate = new Date(post.dateTime);
            const formattedDate = postDate.toLocaleDateString('pt-BR');
            const formattedTime = postDate.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });

            const platformIcons = post.platforms.map(platformId => {
                const social = state.socials.find(s => s.id === platformId);
                return `<i class="${social.icon} ${social.color} text-lg" title="${social.name}"></i>`;
            }).join('');

            const postCard = document.createElement('div');
            postCard.className = 'p-4 border border-gray-200 rounded-lg flex justify-between items-center';
            postCard.innerHTML = `
                <div>
                    <h4 class="font-bold">${post.title}</h4>
                    <p class="text-gray-500 text-xs mt-1"><i class="fas fa-file-video mr-1"></i>${post.file.name}</p>
                    <p class="text-sm text-gray-600 mt-2">
                        <i class="fas fa-calendar-day mr-1"></i> ${formattedDate} às ${formattedTime}
                    </p>
                </div>
                <div class="flex items-center gap-3">
                    ${platformIcons}
                    <button data-post-id="${post.id}" class="cancel-post-btn text-red-500 hover:text-red-700">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
            `;
            scheduledPostsContainer.appendChild(postCard);
        });
    }

    async function openScheduleModal(videoId) {
        const video = state.plannedVideos.find(v => v.id == videoId);
        if (!video) return;

        const connectedSocials = state.socials.filter(s => s.connected);
        if (connectedSocials.length === 0) {
            showNotification('Por favor, conecte pelo menos uma rede social antes de agendar.', 'error');
            return;
        }

        scheduleVideoIdInput.value = video.id;
        modalVideoTitle.textContent = video.title;
        
        const now = new Date();
        now.setDate(now.getDate() + 1);
        scheduleDateInput.value = now.toISOString().split('T')[0];
        scheduleTimeInput.value = '18:00';

        modalSocialPlatformsContainer.innerHTML = '';
        connectedSocials.forEach(social => {
            const checkboxDiv = document.createElement('div');
            checkboxDiv.className = 'flex items-center';
            checkboxDiv.innerHTML = `
                <input id="check-${social.id}" type="checkbox" value="${social.id}" class="h-4 w-4 text-indigo-600 border-gray-300 rounded focus:ring-indigo-500">
                <label for="check-${social.id}" class="ml-2 text-gray-700 flex items-center">
                    <i class="${social.icon} ${social.color} text-xl mr-2"></i>${social.name}
                </label>
            `;
            modalSocialPlatformsContainer.appendChild(checkboxDiv);
        });

        scheduleModal.classList.remove('hidden');
        scheduleModal.classList.add('flex');
    }

    function closeScheduleModal() {
        scheduleModal.classList.add('hidden');
        scheduleModal.classList.remove('flex');
    }

    async function confirmSchedule() {
        const videoId = scheduleVideoIdInput.value;
        const video = state.plannedVideos.find(v => v.id == videoId);
        if (!video) return;

        const scheduleDate = scheduleDateInput.value;
        const scheduleTime = scheduleTimeInput.value;
        const dateTimeString = `${scheduleDate}T${scheduleTime}:00`;

        const selectedPlatforms = Array.from(modalSocialPlatformsContainer.querySelectorAll('input[type="checkbox"]:checked'))
                                    .map(checkbox => checkbox.value);

        if (selectedPlatforms.length === 0) {
            showNotification('Por favor, selecione pelo menos uma plataforma para agendar.', 'error');
            return;
        }

        try {
            const token = localStorage.getItem('authToken');
            const response = await fetch('/api/social/schedule', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}`
                },
                body: JSON.stringify({
                    video_id: videoId,
                    platforms: selectedPlatforms,
                    schedule_time: dateTimeString,
                    content: {
                        title: video.title,
                        description: video.description
                    }
                })
            });

            if (response.ok) {
                const result = await response.json();
                
                const newScheduledPost = {
                    id: result.post_id,
                    videoId: video.id,
                    title: video.title,
                    file: video.file,
                    dateTime: dateTimeString,
                    platforms: selectedPlatforms
                };

                state.scheduledPosts.push(newScheduledPost);
                state.plannedVideos = state.plannedVideos.filter(v => v.id !== videoId);

                localStorage.setItem('scheduledPosts', JSON.stringify(state.scheduledPosts));
                localStorage.setItem('plannedVideos', JSON.stringify(state.plannedVideos));

                renderPlannedVideos();
                renderScheduledPosts();
                closeScheduleModal();

                showNotification('Post agendado com sucesso!', 'success');
            } else {
                throw new Error('Erro ao agendar post');
            }
        } catch (error) {
            showNotification('Erro ao agendar post. Tente novamente.', 'error');
        }
    }

    async function handleConnectSocial(socialId) {
        try {
            const token = localStorage.getItem('authToken');
            const response = await fetch(`/api/social/auth-url/${socialId}`, {
                headers: {
                    'Authorization': `Bearer ${token}`
                }
            });

            if (response.ok) {
                const data = await response.json();
                // Open auth window
                window.open(data.auth_url, 'social-auth', 'width=600,height=600');
                
                // Listen for auth completion
                window.addEventListener('message', (event) => {
                    if (event.data.type === 'social-auth-success') {
                        loadSocialConnections();
                        showNotification(`${socialId} conectado com sucesso!`, 'success');
                    }
                });
            }
        } catch (error) {
            showNotification('Erro ao conectar rede social.', 'error');
        }
    }

    async function loadSocialConnections() {
        try {
            const token = localStorage.getItem('authToken');
            const response = await fetch('/api/social/connections', {
                headers: {
                    'Authorization': `Bearer ${token}`
                }
            });

            if (response.ok) {
                const connections = await response.json();
                state.socials.forEach(social => {
                    social.connected = connections.some(conn => conn.platform === social.id);
                });
                renderSocialAccounts();
            }
        } catch (error) {
            console.error('Error loading social connections:', error);
        }
    }

    async function checkActiveSubscription() {
        try {
            const token = localStorage.getItem('authToken');
            const response = await fetch('/api/subscription/status', {
                headers: {
                    'Authorization': `Bearer ${token}`
                }
            });

            if (response.ok) {
                const subscription = await response.json();
                return subscription.active;
            }
            return false;
        } catch (error) {
            return false;
        }
    }

    // Initial render
    renderSocialAccounts();
    renderPlannedVideos();
    renderScheduledPosts();
}

// Initialize sidebar
function initializeSidebar() {
    const sidebarToggle = document.getElementById('sidebarToggle');
    const sidebarClose = document.getElementById('sidebarClose');
    const sidebar = document.getElementById('sidebar');
    const sidebarOverlay = document.getElementById('sidebarOverlay');

    function openSidebar() {
        sidebar.classList.remove('sidebar-hidden');
        sidebarOverlay.classList.remove('hidden');
    }

    function closeSidebar() {
        sidebar.classList.add('sidebar-hidden');
        sidebarOverlay.classList.add('hidden');
    }

    sidebarToggle?.addEventListener('click', openSidebar);
    sidebarClose?.addEventListener('click', closeSidebar);
    sidebarOverlay?.addEventListener('click', closeSidebar);
}

// Initialize user menu
function initializeUserMenu() {
    const userMenuBtn = document.getElementById('userMenuBtn');
    const userDropdown = document.getElementById('userDropdown');
    const logoutBtn = document.getElementById('logoutBtn');

    userMenuBtn?.addEventListener('click', () => {
        userDropdown.classList.toggle('hidden');
    });

    // Close dropdown when clicking outside
    document.addEventListener('click', (event) => {
        if (!userMenuBtn?.contains(event.target)) {
            userDropdown?.classList.add('hidden');
        }
    });

    logoutBtn?.addEventListener('click', () => {
        localStorage.removeItem('authToken');
        window.location.href = 'login.html';
    });
}

// Utility functions
function formatNumber(num) {
    if (num >= 1000000) {
        return (num / 1000000).toFixed(1) + 'M';
    } else if (num >= 1000) {
        return (num / 1000).toFixed(1) + 'K';
    }
    return num.toString();
}

function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString('pt-BR');
}

function showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = `fixed top-4 right-4 p-4 rounded-lg shadow-lg z-50 ${
        type === 'success' ? 'bg-green-500 text-white' : 
        type === 'error' ? 'bg-red-500 text-white' : 
        'bg-blue-500 text-white'
    }`;
    notification.innerHTML = `
        <div class="flex items-center">
            <i class="fas ${
                type === 'success' ? 'fa-check-circle' : 
                type === 'error' ? 'fa-exclamation-circle' : 
                'fa-info-circle'
            } mr-2"></i>
            <span>${message}</span>
        </div>
    `;
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.remove();
    }, 5000);
}

