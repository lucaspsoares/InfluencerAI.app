from flask import Blueprint, jsonify, request
from src.models.user import User, Video, SocialPost, db
from datetime import datetime, timedelta
import json
import uuid

social_bp = Blueprint('social', __name__)

def token_required(f):
    from src.routes.user import token_required as tr
    return tr(f)

def subscription_required(f):
    from src.routes.user import subscription_required as sr
    return sr(f)

@social_bp.route('/social/platforms', methods=['GET'])
@token_required
def get_platforms(current_user):
    platforms = [
        {
            'name': 'facebook',
            'display_name': 'Facebook',
            'connected': False,  # Em produção, verificar se há token válido
            'features': ['posts', 'stories', 'reels'],
            'max_video_duration': 240,  # 4 minutos
            'supported_formats': ['mp4', 'mov']
        },
        {
            'name': 'tiktok',
            'display_name': 'TikTok',
            'connected': False,
            'features': ['videos'],
            'max_video_duration': 60,  # 1 minuto
            'supported_formats': ['mp4', 'mov']
        },
        {
            'name': 'youtube',
            'display_name': 'YouTube',
            'connected': False,
            'features': ['videos', 'shorts'],
            'max_video_duration': 3600,  # 1 hora para vídeos normais
            'supported_formats': ['mp4', 'mov', 'avi', 'mkv']
        }
    ]
    return jsonify(platforms)

@social_bp.route('/social/connect/<platform>', methods=['POST'])
@token_required
def connect_platform(current_user, platform):
    if platform not in ['facebook', 'tiktok', 'youtube']:
        return jsonify({'message': 'Plataforma não suportada'}), 400
    
    # Em produção, aqui seria feito o OAuth flow
    # Por enquanto, simular conexão
    
    return jsonify({
        'message': f'Conectado ao {platform} com sucesso',
        'auth_url': f'https://oauth.{platform}.com/authorize?client_id=123&redirect_uri=callback',
        'status': 'connected'
    })

@social_bp.route('/social/disconnect/<platform>', methods=['POST'])
@token_required
def disconnect_platform(current_user, platform):
    if platform not in ['facebook', 'tiktok', 'youtube']:
        return jsonify({'message': 'Plataforma não suportada'}), 400
    
    # Em produção, revogar tokens de acesso
    
    return jsonify({
        'message': f'Desconectado do {platform} com sucesso',
        'status': 'disconnected'
    })

@social_bp.route('/social/post', methods=['POST'])
@token_required
@subscription_required
def create_social_post(current_user):
    data = request.json
    
    video_id = data.get('video_id')
    platforms = data.get('platforms', [])
    caption = data.get('caption', '')
    scheduled_at = data.get('scheduled_at')
    
    if not video_id or not platforms:
        return jsonify({'message': 'video_id e platforms são obrigatórios'}), 400
    
    # Verificar se o vídeo existe e pertence ao usuário
    video = Video.query.filter_by(
        id=video_id, 
        user_id=current_user.id
    ).first()
    
    if not video:
        return jsonify({'message': 'Vídeo não encontrado'}), 404
    
    if video.status != 'completed':
        return jsonify({'message': 'Vídeo ainda não foi processado'}), 400
    
    # Validar plataformas
    valid_platforms = ['facebook', 'tiktok', 'youtube']
    for platform in platforms:
        if platform not in valid_platforms:
            return jsonify({'message': f'Plataforma {platform} não suportada'}), 400
    
    # Criar posts para cada plataforma
    created_posts = []
    
    for platform in platforms:
        social_post = SocialPost(
            video_id=video_id,
            platform=platform,
            status='pending'
        )
        
        if scheduled_at:
            try:
                social_post.scheduled_at = datetime.fromisoformat(scheduled_at.replace('Z', '+00:00'))
            except ValueError:
                return jsonify({'message': 'Formato de data inválido'}), 400
        
        db.session.add(social_post)
        db.session.commit()
        
        # Simular publicação
        if not scheduled_at:  # Publicar imediatamente
            success = simulate_post_to_platform(social_post, platform, caption, video)
            if success:
                social_post.status = 'posted'
                social_post.posted_at = datetime.utcnow()
                social_post.post_id = f"{platform}_{uuid.uuid4()}"
            else:
                social_post.status = 'failed'
                social_post.error_message = f'Erro ao publicar no {platform}'
            
            db.session.commit()
        
        created_posts.append(social_post.to_dict())
    
    return jsonify({
        'message': 'Posts criados com sucesso',
        'posts': created_posts
    }), 201

def simulate_post_to_platform(social_post, platform, caption, video):
    """Simula a publicação em uma plataforma social"""
    
    # Verificar limitações da plataforma
    platform_limits = {
        'facebook': {'max_duration': 240, 'max_caption': 2000},
        'tiktok': {'max_duration': 60, 'max_caption': 150},
        'youtube': {'max_duration': 3600, 'max_caption': 5000}
    }
    
    limits = platform_limits.get(platform, {})
    
    # Verificar duração do vídeo
    if video.duration and limits.get('max_duration'):
        if video.duration > limits['max_duration']:
            social_post.error_message = f'Vídeo muito longo para {platform}'
            return False
    
    # Verificar tamanho da legenda
    if len(caption) > limits.get('max_caption', 5000):
        social_post.error_message = f'Legenda muito longa para {platform}'
        return False
    
    # Simular sucesso (90% de chance)
    import random
    return random.random() > 0.1

@social_bp.route('/social/posts', methods=['GET'])
@token_required
def get_user_posts(current_user):
    # Buscar posts dos vídeos do usuário
    posts = db.session.query(SocialPost).join(Video).filter(
        Video.user_id == current_user.id
    ).order_by(SocialPost.created_at.desc()).all()
    
    return jsonify([post.to_dict() for post in posts])

@social_bp.route('/social/posts/<int:post_id>', methods=['GET'])
@token_required
def get_post(current_user, post_id):
    post = db.session.query(SocialPost).join(Video).filter(
        SocialPost.id == post_id,
        Video.user_id == current_user.id
    ).first()
    
    if not post:
        return jsonify({'message': 'Post não encontrado'}), 404
    
    return jsonify(post.to_dict())

@social_bp.route('/social/posts/<int:post_id>/retry', methods=['POST'])
@token_required
def retry_post(current_user, post_id):
    post = db.session.query(SocialPost).join(Video).filter(
        SocialPost.id == post_id,
        Video.user_id == current_user.id
    ).first()
    
    if not post:
        return jsonify({'message': 'Post não encontrado'}), 404
    
    if post.status not in ['failed', 'pending']:
        return jsonify({'message': 'Post não pode ser reprocessado'}), 400
    
    # Tentar publicar novamente
    video = Video.query.get(post.video_id)
    success = simulate_post_to_platform(post, post.platform, '', video)
    
    if success:
        post.status = 'posted'
        post.posted_at = datetime.utcnow()
        post.post_id = f"{post.platform}_{uuid.uuid4()}"
        post.error_message = None
    else:
        post.status = 'failed'
        post.error_message = f'Erro ao republicar no {post.platform}'
    
    db.session.commit()
    
    return jsonify({
        'message': 'Post reprocessado',
        'post': post.to_dict()
    })

@social_bp.route('/social/posts/<int:post_id>/cancel', methods=['POST'])
@token_required
def cancel_post(current_user, post_id):
    post = db.session.query(SocialPost).join(Video).filter(
        SocialPost.id == post_id,
        Video.user_id == current_user.id
    ).first()
    
    if not post:
        return jsonify({'message': 'Post não encontrado'}), 404
    
    if post.status != 'pending':
        return jsonify({'message': 'Post não pode ser cancelado'}), 400
    
    post.status = 'cancelled'
    db.session.commit()
    
    return jsonify({
        'message': 'Post cancelado com sucesso',
        'post': post.to_dict()
    })

@social_bp.route('/social/analytics', methods=['GET'])
@token_required
def get_analytics(current_user):
    # Buscar estatísticas dos posts do usuário
    posts = db.session.query(SocialPost).join(Video).filter(
        Video.user_id == current_user.id
    ).all()
    
    analytics = {
        'total_posts': len(posts),
        'successful_posts': len([p for p in posts if p.status == 'posted']),
        'failed_posts': len([p for p in posts if p.status == 'failed']),
        'pending_posts': len([p for p in posts if p.status == 'pending']),
        'platforms': {
            'facebook': len([p for p in posts if p.platform == 'facebook']),
            'tiktok': len([p for p in posts if p.platform == 'tiktok']),
            'youtube': len([p for p in posts if p.platform == 'youtube'])
        },
        'success_rate': 0
    }
    
    if analytics['total_posts'] > 0:
        analytics['success_rate'] = analytics['successful_posts'] / analytics['total_posts']
    
    return jsonify(analytics)

