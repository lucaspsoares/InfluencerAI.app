from flask import Blueprint, jsonify, request
from src.models.user import User, Subscription, Payment, Video, SocialPost, db
from datetime import datetime, timedelta
import jwt
import os
from functools import wraps

user_bp = Blueprint('user', __name__)

def token_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        token = request.headers.get('Authorization')
        if not token:
            return jsonify({'message': 'Token é obrigatório'}), 401
        
        try:
            if token.startswith('Bearer '):
                token = token[7:]
            data = jwt.decode(token, os.environ.get('SECRET_KEY', 'default-secret'), algorithms=['HS256'])
            current_user = User.query.get(data['user_id'])
            if not current_user:
                return jsonify({'message': 'Token inválido'}), 401
        except jwt.ExpiredSignatureError:
            return jsonify({'message': 'Token expirado'}), 401
        except jwt.InvalidTokenError:
            return jsonify({'message': 'Token inválido'}), 401
        
        return f(current_user, *args, **kwargs)
    return decorated

def subscription_required(f):
    @wraps(f)
    def decorated(current_user, *args, **kwargs):
        if not current_user.has_active_subscription():
            return jsonify({'message': 'Assinatura ativa é obrigatória'}), 403
        return f(current_user, *args, **kwargs)
    return decorated

# Rotas de autenticação
@user_bp.route('/register', methods=['POST'])
def register():
    data = request.json
    
    # Validações
    if not data.get('username') or not data.get('email') or not data.get('password'):
        return jsonify({'message': 'Username, email e senha são obrigatórios'}), 400
    
    # Verificar se usuário já existe
    if User.query.filter_by(username=data['username']).first():
        return jsonify({'message': 'Username já existe'}), 400
    
    if User.query.filter_by(email=data['email']).first():
        return jsonify({'message': 'Email já existe'}), 400
    
    # Criar usuário
    user = User(
        username=data['username'], 
        email=data['email'],
        phone=data.get('phone')
    )
    user.set_password(data['password'])
    
    db.session.add(user)
    db.session.commit()
    
    token = user.generate_token()
    
    return jsonify({
        'message': 'Usuário criado com sucesso',
        'user': user.to_dict(),
        'token': token
    }), 201

@user_bp.route('/login', methods=['POST'])
def login():
    data = request.json
    
    if not data.get('email') or not data.get('password'):
        return jsonify({'message': 'Email e senha são obrigatórios'}), 400
    
    user = User.query.filter_by(email=data['email']).first()
    
    if not user or not user.check_password(data['password']):
        return jsonify({'message': 'Credenciais inválidas'}), 401
    
    if not user.is_active:
        return jsonify({'message': 'Conta desativada'}), 401
    
    token = user.generate_token()
    
    return jsonify({
        'message': 'Login realizado com sucesso',
        'user': user.to_dict(),
        'token': token
    })

@user_bp.route('/profile', methods=['GET'])
@token_required
def get_profile(current_user):
    return jsonify(current_user.to_dict())

@user_bp.route('/profile', methods=['PUT'])
@token_required
def update_profile(current_user):
    data = request.json
    
    if 'username' in data:
        # Verificar se username já existe
        existing_user = User.query.filter_by(username=data['username']).first()
        if existing_user and existing_user.id != current_user.id:
            return jsonify({'message': 'Username já existe'}), 400
        current_user.username = data['username']
    
    if 'email' in data:
        # Verificar se email já existe
        existing_user = User.query.filter_by(email=data['email']).first()
        if existing_user and existing_user.id != current_user.id:
            return jsonify({'message': 'Email já existe'}), 400
        current_user.email = data['email']
    
    if 'phone' in data:
        current_user.phone = data['phone']
    
    if 'password' in data:
        current_user.set_password(data['password'])
    
    db.session.commit()
    
    return jsonify({
        'message': 'Perfil atualizado com sucesso',
        'user': current_user.to_dict()
    })

# Rotas de assinatura
@user_bp.route('/subscriptions/plans', methods=['GET'])
def get_subscription_plans():
    plans = [
        {
            'type': 'weekly',
            'name': 'Plano Semanal',
            'price': 19.99,
            'duration_days': 7,
            'features': [
                'Análise de vídeos com IA',
                'Legendas automáticas',
                'Publicação em redes sociais',
                'Suporte básico'
            ]
        },
        {
            'type': 'monthly',
            'name': 'Plano Mensal',
            'price': 69.99,
            'duration_days': 30,
            'features': [
                'Análise de vídeos com IA',
                'Legendas automáticas',
                'Publicação em redes sociais',
                'Suporte prioritário',
                'Análises avançadas',
                'Relatórios detalhados'
            ]
        }
    ]
    return jsonify(plans)

@user_bp.route('/subscriptions', methods=['POST'])
@token_required
def create_subscription(current_user):
    data = request.json
    
    plan_type = data.get('plan_type')
    if plan_type not in ['weekly', 'monthly']:
        return jsonify({'message': 'Tipo de plano inválido'}), 400
    
    # Definir preço e duração
    if plan_type == 'weekly':
        price = 19.99
        duration_days = 7
    else:
        price = 69.99
        duration_days = 30
    
    # Verificar se já tem assinatura ativa
    if current_user.has_active_subscription():
        return jsonify({'message': 'Usuário já possui assinatura ativa'}), 400
    
    # Criar assinatura
    expires_at = datetime.utcnow() + timedelta(days=duration_days)
    subscription = Subscription(
        user_id=current_user.id,
        plan_type=plan_type,
        price=price,
        expires_at=expires_at
    )
    
    db.session.add(subscription)
    db.session.commit()
    
    return jsonify({
        'message': 'Assinatura criada com sucesso',
        'subscription': subscription.to_dict()
    }), 201

@user_bp.route('/subscriptions', methods=['GET'])
@token_required
def get_user_subscriptions(current_user):
    subscriptions = Subscription.query.filter_by(user_id=current_user.id).all()
    return jsonify([sub.to_dict() for sub in subscriptions])

@user_bp.route('/subscriptions/<int:subscription_id>/cancel', methods=['POST'])
@token_required
def cancel_subscription(current_user, subscription_id):
    subscription = Subscription.query.filter_by(
        id=subscription_id, 
        user_id=current_user.id
    ).first_or_404()
    
    subscription.auto_renew = False
    db.session.commit()
    
    return jsonify({
        'message': 'Assinatura cancelada com sucesso',
        'subscription': subscription.to_dict()
    })

# Rotas básicas de usuário (mantidas para compatibilidade)
@user_bp.route('/users', methods=['GET'])
def get_users():
    users = User.query.all()
    return jsonify([user.to_dict() for user in users])

@user_bp.route('/users/<int:user_id>', methods=['GET'])
def get_user(user_id):
    user = User.query.get_or_404(user_id)
    return jsonify(user.to_dict())
