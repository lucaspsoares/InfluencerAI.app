from flask import Blueprint, jsonify, request
from src.models.user import User, Subscription, Payment, db
from datetime import datetime, timedelta
import uuid
import json

payment_bp = Blueprint('payment', __name__)

def token_required(f):
    from src.routes.user import token_required as tr
    return tr(f)

@payment_bp.route('/payments/create', methods=['POST'])
@token_required
def create_payment(current_user):
    data = request.json
    
    subscription_id = data.get('subscription_id')
    payment_method = data.get('payment_method')
    
    if not subscription_id or not payment_method:
        return jsonify({'message': 'subscription_id e payment_method são obrigatórios'}), 400
    
    if payment_method not in ['pix', 'credit_card']:
        return jsonify({'message': 'Método de pagamento inválido'}), 400
    
    # Verificar se a assinatura existe e pertence ao usuário
    subscription = Subscription.query.filter_by(
        id=subscription_id, 
        user_id=current_user.id
    ).first()
    
    if not subscription:
        return jsonify({'message': 'Assinatura não encontrada'}), 404
    
    # Criar pagamento
    payment = Payment(
        user_id=current_user.id,
        subscription_id=subscription_id,
        amount=subscription.price,
        payment_method=payment_method,
        transaction_id=str(uuid.uuid4())
    )
    
    db.session.add(payment)
    db.session.commit()
    
    # Simular resposta do gateway de pagamento
    if payment_method == 'pix':
        payment_data = {
            'payment_id': payment.id,
            'transaction_id': payment.transaction_id,
            'amount': payment.amount,
            'payment_method': payment_method,
            'pix_code': f'00020126580014BR.GOV.BCB.PIX0136{payment.transaction_id}5204000053039865802BR5925PLATAFORMA VIDEO AI6009SAO PAULO62070503***6304',
            'qr_code_url': f'/api/payments/{payment.id}/qr-code',
            'expires_at': (datetime.utcnow() + timedelta(minutes=30)).isoformat(),
            'status': 'pending'
        }
    else:  # credit_card
        payment_data = {
            'payment_id': payment.id,
            'transaction_id': payment.transaction_id,
            'amount': payment.amount,
            'payment_method': payment_method,
            'card_form_url': f'/api/payments/{payment.id}/card-form',
            'status': 'pending'
        }
    
    return jsonify({
        'message': 'Pagamento criado com sucesso',
        'payment': payment_data
    }), 201

@payment_bp.route('/payments/<int:payment_id>/confirm', methods=['POST'])
@token_required
def confirm_payment(current_user, payment_id):
    payment = Payment.query.filter_by(
        id=payment_id, 
        user_id=current_user.id
    ).first()
    
    if not payment:
        return jsonify({'message': 'Pagamento não encontrado'}), 404
    
    if payment.payment_status != 'pending':
        return jsonify({'message': 'Pagamento já processado'}), 400
    
    # Simular confirmação do pagamento
    payment.payment_status = 'completed'
    payment.paid_at = datetime.utcnow()
    
    # Ativar assinatura
    subscription = Subscription.query.get(payment.subscription_id)
    if subscription:
        subscription.is_active = True
    
    db.session.commit()
    
    return jsonify({
        'message': 'Pagamento confirmado com sucesso',
        'payment': payment.to_dict()
    })

@payment_bp.route('/payments/<int:payment_id>/qr-code', methods=['GET'])
def get_pix_qr_code(payment_id):
    payment = Payment.query.get_or_404(payment_id)
    
    if payment.payment_method != 'pix':
        return jsonify({'message': 'QR Code disponível apenas para pagamentos PIX'}), 400
    
    # Simular geração de QR Code
    qr_code_data = {
        'payment_id': payment.id,
        'pix_code': f'00020126580014BR.GOV.BCB.PIX0136{payment.transaction_id}5204000053039865802BR5925PLATAFORMA VIDEO AI6009SAO PAULO62070503***6304',
        'amount': payment.amount,
        'expires_at': (payment.created_at + timedelta(minutes=30)).isoformat()
    }
    
    return jsonify(qr_code_data)

@payment_bp.route('/payments/<int:payment_id>/card-form', methods=['GET'])
def get_card_form(payment_id):
    payment = Payment.query.get_or_404(payment_id)
    
    if payment.payment_method != 'credit_card':
        return jsonify({'message': 'Formulário disponível apenas para pagamentos com cartão'}), 400
    
    # Simular dados do formulário de cartão
    form_data = {
        'payment_id': payment.id,
        'amount': payment.amount,
        'installments': [
            {'number': 1, 'amount': payment.amount, 'total': payment.amount},
            {'number': 2, 'amount': payment.amount / 2, 'total': payment.amount * 1.05},
            {'number': 3, 'amount': payment.amount / 3, 'total': payment.amount * 1.10}
        ]
    }
    
    return jsonify(form_data)

@payment_bp.route('/payments/<int:payment_id>/process-card', methods=['POST'])
@token_required
def process_card_payment(current_user, payment_id):
    payment = Payment.query.filter_by(
        id=payment_id, 
        user_id=current_user.id
    ).first()
    
    if not payment:
        return jsonify({'message': 'Pagamento não encontrado'}), 404
    
    if payment.payment_status != 'pending':
        return jsonify({'message': 'Pagamento já processado'}), 400
    
    data = request.json
    
    # Validar dados do cartão (simulação)
    required_fields = ['card_number', 'card_holder', 'expiry_month', 'expiry_year', 'cvv']
    for field in required_fields:
        if not data.get(field):
            return jsonify({'message': f'Campo {field} é obrigatório'}), 400
    
    # Simular processamento do cartão
    # Em produção, aqui seria feita a integração com o gateway de pagamento
    payment.payment_status = 'completed'
    payment.paid_at = datetime.utcnow()
    
    # Ativar assinatura
    subscription = Subscription.query.get(payment.subscription_id)
    if subscription:
        subscription.is_active = True
    
    db.session.commit()
    
    return jsonify({
        'message': 'Pagamento processado com sucesso',
        'payment': payment.to_dict()
    })

@payment_bp.route('/payments', methods=['GET'])
@token_required
def get_user_payments(current_user):
    payments = Payment.query.filter_by(user_id=current_user.id).order_by(Payment.created_at.desc()).all()
    return jsonify([payment.to_dict() for payment in payments])

@payment_bp.route('/payments/<int:payment_id>', methods=['GET'])
@token_required
def get_payment(current_user, payment_id):
    payment = Payment.query.filter_by(
        id=payment_id, 
        user_id=current_user.id
    ).first()
    
    if not payment:
        return jsonify({'message': 'Pagamento não encontrado'}), 404
    
    return jsonify(payment.to_dict())

