from flask import Blueprint, jsonify, request, send_file
from src.models.user import User, Video, SocialPost, db
from datetime import datetime
import os
import uuid
import json
from werkzeug.utils import secure_filename

video_bp = Blueprint('video', __name__)

def token_required(f):
    from src.routes.user import token_required as tr
    return tr(f)

def subscription_required(f):
    from src.routes.user import subscription_required as sr
    return sr(f)

UPLOAD_FOLDER = '/home/ubuntu/video-ai-platform/uploads'
ALLOWED_EXTENSIONS = {'mp4', 'avi', 'mov', 'mkv', 'wmv', 'flv', 'webm'}

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def ensure_upload_folder():
    if not os.path.exists(UPLOAD_FOLDER):
        os.makedirs(UPLOAD_FOLDER)

@video_bp.route('/videos/upload', methods=['POST'])
@token_required
@subscription_required
def upload_video(current_user):
    ensure_upload_folder()
    
    if 'video' not in request.files:
        return jsonify({'message': 'Nenhum arquivo de vídeo enviado'}), 400
    
    file = request.files['video']
    title = request.form.get('title', '')
    
    if file.filename == '':
        return jsonify({'message': 'Nenhum arquivo selecionado'}), 400
    
    if not allowed_file(file.filename):
        return jsonify({'message': 'Formato de arquivo não suportado'}), 400
    
    if not title:
        title = file.filename.rsplit('.', 1)[0]
    
    # Gerar nome único para o arquivo
    filename = secure_filename(file.filename)
    unique_filename = f"{uuid.uuid4()}_{filename}"
    file_path = os.path.join(UPLOAD_FOLDER, unique_filename)
    
    # Salvar arquivo
    file.save(file_path)
    
    # Criar registro no banco
    video = Video(
        user_id=current_user.id,
        title=title,
        original_filename=filename,
        file_path=file_path,
        status='uploaded'
    )
    
    db.session.add(video)
    db.session.commit()
    
    # Iniciar processamento assíncrono (simulado)
    # Em produção, isso seria feito em uma fila de tarefas (Celery, RQ, etc.)
    
    return jsonify({
        'message': 'Vídeo enviado com sucesso',
        'video': video.to_dict()
    }), 201

@video_bp.route('/videos/<int:video_id>/process', methods=['POST'])
@token_required
@subscription_required
def process_video(current_user, video_id):
    video = Video.query.filter_by(
        id=video_id, 
        user_id=current_user.id
    ).first()
    
    if not video:
        return jsonify({'message': 'Vídeo não encontrado'}), 404
    
    if video.status != 'uploaded':
        return jsonify({'message': 'Vídeo já está sendo processado ou foi processado'}), 400
    
    # Atualizar status
    video.status = 'processing'
    db.session.commit()
    
    # Simular processamento com IA
    # Em produção, isso seria feito em background
    try:
        # Simular análise de IA
        ai_analysis = {
            'duration': 120.5,
            'scenes': [
                {'start': 0, 'end': 30, 'description': 'Introdução', 'score': 0.8},
                {'start': 30, 'end': 60, 'description': 'Conteúdo principal', 'score': 0.95},
                {'start': 60, 'end': 90, 'description': 'Demonstração', 'score': 0.9},
                {'start': 90, 'end': 120, 'description': 'Conclusão', 'score': 0.7}
            ],
            'emotions': ['alegria', 'surpresa', 'interesse'],
            'objects': ['pessoa', 'computador', 'texto'],
            'audio_quality': 0.85,
            'video_quality': 0.9
        }
        
        # Identificar melhores momentos
        best_moments = [
            {
                'start': 30,
                'end': 60,
                'title': 'Momento Principal',
                'description': 'Parte mais interessante do vídeo',
                'score': 0.95,
                'suggested_caption': 'Veja este momento incrível! 🔥'
            },
            {
                'start': 60,
                'end': 90,
                'title': 'Demonstração Prática',
                'description': 'Demonstração clara e objetiva',
                'score': 0.9,
                'suggested_caption': 'Tutorial prático que você precisa ver! 💡'
            }
        ]
        
        # Atualizar vídeo
        video.status = 'completed'
        video.duration = ai_analysis['duration']
        video.ai_analysis = json.dumps(ai_analysis)
        video.best_moments = json.dumps(best_moments)
        video.processed_at = datetime.utcnow()
        
        db.session.commit()
        
        return jsonify({
            'message': 'Vídeo processado com sucesso',
            'video': video.to_dict(),
            'ai_analysis': ai_analysis,
            'best_moments': best_moments
        })
        
    except Exception as e:
        video.status = 'error'
        db.session.commit()
        return jsonify({'message': f'Erro no processamento: {str(e)}'}), 500

@video_bp.route('/videos', methods=['GET'])
@token_required
def get_user_videos(current_user):
    videos = Video.query.filter_by(user_id=current_user.id).order_by(Video.created_at.desc()).all()
    return jsonify([video.to_dict() for video in videos])

@video_bp.route('/videos/<int:video_id>', methods=['GET'])
@token_required
def get_video(current_user, video_id):
    video = Video.query.filter_by(
        id=video_id, 
        user_id=current_user.id
    ).first()
    
    if not video:
        return jsonify({'message': 'Vídeo não encontrado'}), 404
    
    video_data = video.to_dict()
    
    # Adicionar análise da IA se disponível
    if video.ai_analysis:
        video_data['ai_analysis'] = json.loads(video.ai_analysis)
    
    if video.best_moments:
        video_data['best_moments'] = json.loads(video.best_moments)
    
    return jsonify(video_data)

@video_bp.route('/videos/<int:video_id>/best-moments', methods=['GET'])
@token_required
def get_video_best_moments(current_user, video_id):
    video = Video.query.filter_by(
        id=video_id, 
        user_id=current_user.id
    ).first()
    
    if not video:
        return jsonify({'message': 'Vídeo não encontrado'}), 404
    
    if not video.best_moments:
        return jsonify({'message': 'Vídeo ainda não foi processado'}), 400
    
    best_moments = json.loads(video.best_moments)
    return jsonify(best_moments)

@video_bp.route('/videos/<int:video_id>/generate-clips', methods=['POST'])
@token_required
@subscription_required
def generate_clips(current_user, video_id):
    video = Video.query.filter_by(
        id=video_id, 
        user_id=current_user.id
    ).first()
    
    if not video:
        return jsonify({'message': 'Vídeo não encontrado'}), 404
    
    if not video.best_moments:
        return jsonify({'message': 'Vídeo ainda não foi processado'}), 400
    
    data = request.json
    moments = data.get('moments', [])
    
    if not moments:
        return jsonify({'message': 'Nenhum momento selecionado'}), 400
    
    # Simular geração de clipes com legendas
    generated_clips = []
    
    for moment in moments:
        clip_data = {
            'id': str(uuid.uuid4()),
            'start': moment.get('start'),
            'end': moment.get('end'),
            'title': moment.get('title'),
            'file_path': f"/clips/{video_id}_{moment.get('start')}_{moment.get('end')}.mp4",
            'subtitles': [
                {
                    'start': moment.get('start'),
                    'end': moment.get('start') + 3,
                    'text': moment.get('suggested_caption', 'Momento incrível!'),
                    'style': {
                        'color': '#FFFF00',  # Amarelo
                        'fontSize': '24px',
                        'fontWeight': 'bold',
                        'position': 'bottom'
                    }
                }
            ],
            'status': 'generated'
        }
        generated_clips.append(clip_data)
    
    return jsonify({
        'message': 'Clipes gerados com sucesso',
        'clips': generated_clips
    })

@video_bp.route('/videos/<int:video_id>/delete', methods=['DELETE'])
@token_required
def delete_video(current_user, video_id):
    video = Video.query.filter_by(
        id=video_id, 
        user_id=current_user.id
    ).first()
    
    if not video:
        return jsonify({'message': 'Vídeo não encontrado'}), 404
    
    # Remover arquivo físico
    if os.path.exists(video.file_path):
        os.remove(video.file_path)
    
    # Remover do banco
    db.session.delete(video)
    db.session.commit()
    
    return jsonify({'message': 'Vídeo removido com sucesso'})

@video_bp.route('/videos/<int:video_id>/download', methods=['GET'])
@token_required
def download_video(current_user, video_id):
    video = Video.query.filter_by(
        id=video_id, 
        user_id=current_user.id
    ).first()
    
    if not video:
        return jsonify({'message': 'Vídeo não encontrado'}), 404
    
    if not os.path.exists(video.file_path):
        return jsonify({'message': 'Arquivo não encontrado'}), 404
    
    return send_file(
        video.file_path,
        as_attachment=True,
        download_name=video.original_filename
    )

