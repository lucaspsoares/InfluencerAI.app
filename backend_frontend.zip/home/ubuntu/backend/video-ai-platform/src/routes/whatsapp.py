from flask import Blueprint, jsonify, request
from src.models.user import User, Subscription, Payment, db
from datetime import datetime, timedelta
import json
import uuid

whatsapp_bp = Blueprint('whatsapp', __name__)

def token_required(f):
    from src.routes.user import token_required as tr
    return tr(f)

@whatsapp_bp.route('/whatsapp/config', methods=['GET'])
@token_required
def get_whatsapp_config(current_user):
    """Obter configurações do WhatsApp para o usuário"""
    
    config = {
        'phone_verified': bool(current_user.phone),
        'phone_number': current_user.phone,
        'notifications_enabled': True,  # Em produção, seria um campo no banco
        'billing_reminders': True,
        'reminder_days': [7, 3, 1]  # Dias antes do vencimento para enviar lembrete
    }
    
    return jsonify(config)

@whatsapp_bp.route('/whatsapp/config', methods=['PUT'])
@token_required
def update_whatsapp_config(current_user):
    """Atualizar configurações do WhatsApp"""
    
    data = request.json
    
    if 'phone_number' in data:
        # Validar formato do telefone
        phone = data['phone_number'].strip()
        if not phone.startswith('+'):
            phone = '+55' + phone  # Assumir Brasil se não especificado
        
        current_user.phone = phone
        db.session.commit()
    
    return jsonify({
        'message': 'Configurações atualizadas com sucesso',
        'config': {
            'phone_verified': bool(current_user.phone),
            'phone_number': current_user.phone
        }
    })

@whatsapp_bp.route('/whatsapp/verify-phone', methods=['POST'])
@token_required
def verify_phone(current_user):
    """Iniciar verificação do telefone via WhatsApp"""
    
    if not current_user.phone:
        return jsonify({'message': 'Número de telefone não configurado'}), 400
    
    # Simular envio de código de verificação
    verification_code = str(uuid.uuid4())[:6].upper()
    
    # Em produção, salvar o código no banco com expiração
    # e enviar via API do WhatsApp
    
    message = f"""
🔐 *Código de Verificação - Plataforma Video AI*

Seu código de verificação é: *{verification_code}*

Este código expira em 5 minutos.

Se você não solicitou este código, ignore esta mensagem.
    """.strip()
    
    # Simular envio
    success = simulate_whatsapp_send(current_user.phone, message)
    
    if success:
        return jsonify({
            'message': 'Código de verificação enviado',
            'phone': current_user.phone,
            'verification_code': verification_code  # Apenas para teste
        })
    else:
        return jsonify({'message': 'Erro ao enviar código de verificação'}), 500

@whatsapp_bp.route('/whatsapp/send-billing-reminder', methods=['POST'])
def send_billing_reminder():
    """Enviar lembretes de cobrança (chamado por cron job)"""
    
    # Buscar assinaturas que vencem em breve
    reminder_dates = [
        datetime.utcnow() + timedelta(days=7),
        datetime.utcnow() + timedelta(days=3),
        datetime.utcnow() + timedelta(days=1)
    ]
    
    sent_reminders = []
    
    for reminder_date in reminder_dates:
        # Buscar assinaturas que vencem nesta data
        subscriptions = Subscription.query.filter(
            Subscription.expires_at.between(
                reminder_date.replace(hour=0, minute=0, second=0),
                reminder_date.replace(hour=23, minute=59, second=59)
            ),
            Subscription.is_active == True,
            Subscription.auto_renew == True
        ).all()
        
        for subscription in subscriptions:
            user = User.query.get(subscription.user_id)
            if user and user.phone:
                days_until_expiry = (subscription.expires_at - datetime.utcnow()).days
                
                message = generate_billing_reminder_message(user, subscription, days_until_expiry)
                success = simulate_whatsapp_send(user.phone, message)
                
                if success:
                    sent_reminders.append({
                        'user_id': user.id,
                        'subscription_id': subscription.id,
                        'phone': user.phone,
                        'days_until_expiry': days_until_expiry
                    })
    
    return jsonify({
        'message': f'{len(sent_reminders)} lembretes enviados',
        'reminders': sent_reminders
    })

@whatsapp_bp.route('/whatsapp/send-payment-confirmation', methods=['POST'])
@token_required
def send_payment_confirmation(current_user):
    """Enviar confirmação de pagamento via WhatsApp"""
    
    data = request.json
    payment_id = data.get('payment_id')
    
    if not payment_id:
        return jsonify({'message': 'payment_id é obrigatório'}), 400
    
    payment = Payment.query.filter_by(
        id=payment_id,
        user_id=current_user.id
    ).first()
    
    if not payment:
        return jsonify({'message': 'Pagamento não encontrado'}), 404
    
    if not current_user.phone:
        return jsonify({'message': 'Número de telefone não configurado'}), 400
    
    message = generate_payment_confirmation_message(current_user, payment)
    success = simulate_whatsapp_send(current_user.phone, message)
    
    if success:
        return jsonify({
            'message': 'Confirmação de pagamento enviada',
            'phone': current_user.phone
        })
    else:
        return jsonify({'message': 'Erro ao enviar confirmação'}), 500

@whatsapp_bp.route('/whatsapp/send-overdue-notice', methods=['POST'])
def send_overdue_notices():
    """Enviar avisos de vencimento (chamado por cron job)"""
    
    # Buscar assinaturas vencidas
    overdue_subscriptions = Subscription.query.filter(
        Subscription.expires_at < datetime.utcnow(),
        Subscription.is_active == True
    ).all()
    
    sent_notices = []
    
    for subscription in overdue_subscriptions:
        user = User.query.get(subscription.user_id)
        if user and user.phone:
            days_overdue = (datetime.utcnow() - subscription.expires_at).days
            
            message = generate_overdue_notice_message(user, subscription, days_overdue)
            success = simulate_whatsapp_send(user.phone, message)
            
            if success:
                sent_notices.append({
                    'user_id': user.id,
                    'subscription_id': subscription.id,
                    'phone': user.phone,
                    'days_overdue': days_overdue
                })
                
                # Desativar assinatura se muito tempo vencida
                if days_overdue > 7:
                    subscription.is_active = False
                    db.session.commit()
    
    return jsonify({
        'message': f'{len(sent_notices)} avisos de vencimento enviados',
        'notices': sent_notices
    })

def simulate_whatsapp_send(phone, message):
    """Simula o envio de mensagem via WhatsApp"""
    
    # Em produção, aqui seria feita a integração com a API do WhatsApp Business
    # Por exemplo: Twilio, Meta WhatsApp Business API, etc.
    
    print(f"📱 WhatsApp para {phone}:")
    print(message)
    print("-" * 50)
    
    # Simular sucesso (95% de chance)
    import random
    return random.random() > 0.05

def generate_billing_reminder_message(user, subscription, days_until_expiry):
    """Gerar mensagem de lembrete de cobrança"""
    
    plan_name = "Plano Semanal" if subscription.plan_type == "weekly" else "Plano Mensal"
    
    if days_until_expiry == 1:
        urgency = "⚠️ *ÚLTIMO DIA*"
    elif days_until_expiry <= 3:
        urgency = "🔔 *ATENÇÃO*"
    else:
        urgency = "📅 *LEMBRETE*"
    
    message = f"""
{urgency}

Olá {user.username}! 👋

Sua assinatura do *{plan_name}* vence em *{days_until_expiry} dia(s)*.

💰 Valor: R$ {subscription.price:.2f}
📅 Vencimento: {subscription.expires_at.strftime('%d/%m/%Y')}

Para renovar automaticamente, acesse:
🔗 https://plataforma-video-ai.com/billing

Dúvidas? Responda esta mensagem!

---
*Plataforma Video AI* 🎬
    """.strip()
    
    return message

def generate_payment_confirmation_message(user, payment):
    """Gerar mensagem de confirmação de pagamento"""
    
    subscription = Subscription.query.get(payment.subscription_id)
    plan_name = "Plano Semanal" if subscription.plan_type == "weekly" else "Plano Mensal"
    
    message = f"""
✅ *PAGAMENTO CONFIRMADO*

Olá {user.username}! 👋

Seu pagamento foi processado com sucesso!

💳 Valor: R$ {payment.amount:.2f}
📋 Plano: {plan_name}
🆔 Transação: {payment.transaction_id[:8]}...
📅 Data: {payment.paid_at.strftime('%d/%m/%Y às %H:%M')}

Sua assinatura está ativa até {subscription.expires_at.strftime('%d/%m/%Y')}.

Aproveite todos os recursos da plataforma! 🎬

---
*Plataforma Video AI* 🎬
    """.strip()
    
    return message

def generate_overdue_notice_message(user, subscription, days_overdue):
    """Gerar mensagem de aviso de vencimento"""
    
    plan_name = "Plano Semanal" if subscription.plan_type == "weekly" else "Plano Mensal"
    
    if days_overdue <= 3:
        tone = "🔔 *ASSINATURA VENCIDA*"
        action = "Renove agora para continuar usando todos os recursos!"
    else:
        tone = "⚠️ *ACESSO SUSPENSO*"
        action = "Sua conta será desativada em breve. Renove agora!"
    
    message = f"""
{tone}

Olá {user.username}! 👋

Sua assinatura do *{plan_name}* venceu há *{days_overdue} dia(s)*.

💰 Valor: R$ {subscription.price:.2f}
📅 Venceu em: {subscription.expires_at.strftime('%d/%m/%Y')}

{action}

Para renovar, acesse:
🔗 https://plataforma-video-ai.com/billing

Precisa de ajuda? Responda esta mensagem!

---
*Plataforma Video AI* 🎬
    """.strip()
    
    return message

@whatsapp_bp.route('/whatsapp/test-message', methods=['POST'])
@token_required
def test_message(current_user):
    """Enviar mensagem de teste"""
    
    if not current_user.phone:
        return jsonify({'message': 'Número de telefone não configurado'}), 400
    
    message = f"""
🧪 *MENSAGEM DE TESTE*

Olá {current_user.username}! 👋

Esta é uma mensagem de teste da *Plataforma Video AI*.

Se você recebeu esta mensagem, significa que as notificações via WhatsApp estão funcionando corretamente! ✅

---
*Plataforma Video AI* 🎬
    """.strip()
    
    success = simulate_whatsapp_send(current_user.phone, message)
    
    if success:
        return jsonify({
            'message': 'Mensagem de teste enviada',
            'phone': current_user.phone
        })
    else:
        return jsonify({'message': 'Erro ao enviar mensagem de teste'}), 500

