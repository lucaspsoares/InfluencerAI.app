import uuid
import hashlib
import time
from datetime import datetime, timedelta
from typing import Dict, Any, Optional
import json
import random
import string

class PaymentService:
    """Serviço para processamento de pagamentos PIX e cartão de crédito"""
    
    def __init__(self):
        self.pix_payments = {}
        self.card_payments = {}
        
    def generate_pix_payment(self, amount: float, description: str, user_id: int) -> Dict[str, Any]:
        """Gera um pagamento PIX"""
        payment_id = str(uuid.uuid4())
        
        # Gerar código PIX simulado
        pix_code = self._generate_pix_code(amount, description)
        
        # Gerar QR Code (simulado)
        qr_code_data = f"PIX|{payment_id}|{amount}|{description}"
        
        payment_data = {
            'payment_id': payment_id,
            'user_id': user_id,
            'amount': amount,
            'description': description,
            'payment_method': 'pix',
            'status': 'pending',
            'pix_code': pix_code,
            'qr_code_data': qr_code_data,
            'expires_at': (datetime.now() + timedelta(minutes=30)).isoformat(),
            'created_at': datetime.now().isoformat()
        }
        
        self.pix_payments[payment_id] = payment_data
        return payment_data
    
    def process_card_payment(self, amount: float, description: str, user_id: int, 
                           card_data: Dict[str, str]) -> Dict[str, Any]:
        """Processa pagamento com cartão de crédito"""
        payment_id = str(uuid.uuid4())
        
        # Validar dados do cartão
        validation_result = self._validate_card_data(card_data)
        if not validation_result['valid']:
            return {
                'success': False,
                'message': validation_result['message'],
                'payment_id': payment_id
            }
        
        # Simular processamento (90% de sucesso)
        success = random.random() > 0.1
        
        payment_data = {
            'payment_id': payment_id,
            'user_id': user_id,
            'amount': amount,
            'description': description,
            'payment_method': 'credit_card',
            'status': 'approved' if success else 'declined',
            'card_last_digits': card_data['number'][-4:],
            'authorization_code': self._generate_auth_code() if success else None,
            'created_at': datetime.now().isoformat(),
            'processed_at': datetime.now().isoformat() if success else None
        }
        
        self.card_payments[payment_id] = payment_data
        
        return {
            'success': success,
            'payment': payment_data,
            'message': 'Pagamento aprovado' if success else 'Pagamento recusado'
        }
    
    def confirm_pix_payment(self, payment_id: str) -> Dict[str, Any]:
        """Confirma um pagamento PIX (simula verificação)"""
        if payment_id not in self.pix_payments:
            return {
                'success': False,
                'message': 'Pagamento não encontrado'
            }
        
        payment = self.pix_payments[payment_id]
        
        # Verificar se não expirou
        expires_at = datetime.fromisoformat(payment['expires_at'])
        if datetime.now() > expires_at:
            payment['status'] = 'expired'
            return {
                'success': False,
                'message': 'Pagamento expirado'
            }
        
        # Simular confirmação (80% de sucesso para PIX)
        success = random.random() > 0.2
        
        if success:
            payment['status'] = 'approved'
            payment['processed_at'] = datetime.now().isoformat()
            payment['transaction_id'] = self._generate_transaction_id()
        else:
            payment['status'] = 'pending'
        
        return {
            'success': success,
            'payment': payment,
            'message': 'Pagamento confirmado' if success else 'Pagamento ainda não identificado'
        }
    
    def get_payment_status(self, payment_id: str) -> Optional[Dict[str, Any]]:
        """Obtém status de um pagamento"""
        if payment_id in self.pix_payments:
            return self.pix_payments[payment_id]
        elif payment_id in self.card_payments:
            return self.card_payments[payment_id]
        return None
    
    def _generate_pix_code(self, amount: float, description: str) -> str:
        """Gera código PIX simulado"""
        # Código PIX simulado baseado no padrão EMV
        base_string = f"{amount}{description}{time.time()}"
        hash_object = hashlib.md5(base_string.encode())
        return hash_object.hexdigest().upper()[:32]
    
    def _generate_auth_code(self) -> str:
        """Gera código de autorização para cartão"""
        return ''.join(random.choices(string.ascii_uppercase + string.digits, k=6))
    
    def _generate_transaction_id(self) -> str:
        """Gera ID de transação"""
        return ''.join(random.choices(string.digits, k=12))
    
    def _validate_card_data(self, card_data: Dict[str, str]) -> Dict[str, Any]:
        """Valida dados do cartão de crédito"""
        required_fields = ['number', 'holder', 'expiry_month', 'expiry_year', 'cvv']
        
        for field in required_fields:
            if field not in card_data or not card_data[field]:
                return {
                    'valid': False,
                    'message': f'Campo {field} é obrigatório'
                }
        
        # Validar número do cartão (Luhn algorithm simplificado)
        card_number = card_data['number'].replace(' ', '').replace('-', '')
        if not card_number.isdigit() or len(card_number) < 13 or len(card_number) > 19:
            return {
                'valid': False,
                'message': 'Número do cartão inválido'
            }
        
        # Validar data de validade
        try:
            month = int(card_data['expiry_month'])
            year = int(card_data['expiry_year'])
            
            if month < 1 or month > 12:
                return {
                    'valid': False,
                    'message': 'Mês de validade inválido'
                }
            
            current_year = datetime.now().year % 100
            if year < current_year or (year == current_year and month < datetime.now().month):
                return {
                    'valid': False,
                    'message': 'Cartão vencido'
                }
                
        except ValueError:
            return {
                'valid': False,
                'message': 'Data de validade inválida'
            }
        
        # Validar CVV
        cvv = card_data['cvv']
        if not cvv.isdigit() or len(cvv) < 3 or len(cvv) > 4:
            return {
                'valid': False,
                'message': 'CVV inválido'
            }
        
        return {'valid': True}

# Instância global do serviço
payment_service = PaymentService()

