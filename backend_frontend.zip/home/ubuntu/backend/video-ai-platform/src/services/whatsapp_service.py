import uuid
import json
import time
import random
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional
import requests
import re

class WhatsAppService:
    """Serviço para envio de mensagens e cobrança automática via WhatsApp"""
    
    def __init__(self):
        self.verified_numbers = {}
        self.message_history = {}
        self.scheduled_messages = {}
        
        # Configurações da API do WhatsApp Business
        self.api_config = {
            'base_url': 'https://graph.facebook.com/v18.0',
            'phone_number_id': '123456789',  # Simulado
            'access_token': 'whatsapp_token_123',  # Simulado
            'webhook_verify_token': 'webhook_verify_123'
        }
        
        # Templates de mensagens
        self.message_templates = {
            'payment_reminder_7_days': {
                'name': 'payment_reminder_7_days',
                'language': 'pt_BR',
                'components': [
                    {
                        'type': 'body',
                        'parameters': [
                            {'type': 'text', 'text': '{{username}}'},
                            {'type': 'text', 'text': '{{plan_name}}'},
                            {'type': 'text', 'text': '{{amount}}'},
                            {'type': 'text', 'text': '{{due_date}}'}
                        ]
                    }
                ]
            },
            'payment_reminder_3_days': {
                'name': 'payment_reminder_3_days',
                'language': 'pt_BR',
                'components': [
                    {
                        'type': 'body',
                        'parameters': [
                            {'type': 'text', 'text': '{{username}}'},
                            {'type': 'text', 'text': '{{plan_name}}'},
                            {'type': 'text', 'text': '{{amount}}'},
                            {'type': 'text', 'text': '{{due_date}}'}
                        ]
                    }
                ]
            },
            'payment_reminder_1_day': {
                'name': 'payment_reminder_1_day',
                'language': 'pt_BR',
                'components': [
                    {
                        'type': 'body',
                        'parameters': [
                            {'type': 'text', 'text': '{{username}}'},
                            {'type': 'text', 'text': '{{plan_name}}'},
                            {'type': 'text', 'text': '{{amount}}'}
                        ]
                    }
                ]
            },
            'payment_confirmation': {
                'name': 'payment_confirmation',
                'language': 'pt_BR',
                'components': [
                    {
                        'type': 'body',
                        'parameters': [
                            {'type': 'text', 'text': '{{username}}'},
                            {'type': 'text', 'text': '{{amount}}'},
                            {'type': 'text', 'text': '{{plan_name}}'},
                            {'type': 'text', 'text': '{{next_due_date}}'}
                        ]
                    }
                ]
            },
            'payment_overdue': {
                'name': 'payment_overdue',
                'language': 'pt_BR',
                'components': [
                    {
                        'type': 'body',
                        'parameters': [
                            {'type': 'text', 'text': '{{username}}'},
                            {'type': 'text', 'text': '{{plan_name}}'},
                            {'type': 'text', 'text': '{{overdue_days}}'}
                        ]
                    }
                ]
            }
        }
    
    def verify_phone_number(self, user_id: int, phone_number: str) -> Dict[str, Any]:
        """Inicia verificação de número de telefone"""
        # Validar formato do número
        if not self._validate_phone_number(phone_number):
            return {
                'success': False,
                'message': 'Número de telefone inválido'
            }
        
        # Gerar código de verificação
        verification_code = str(random.randint(100000, 999999))
        
        # Armazenar para verificação
        verification_id = str(uuid.uuid4())
        self.verified_numbers[verification_id] = {
            'user_id': user_id,
            'phone_number': phone_number,
            'verification_code': verification_code,
            'verified': False,
            'created_at': datetime.now().isoformat(),
            'expires_at': (datetime.now() + timedelta(minutes=10)).isoformat()
        }
        
        # Simular envio de código via WhatsApp
        message_result = self._send_verification_code(phone_number, verification_code)
        
        if message_result['success']:
            return {
                'success': True,
                'verification_id': verification_id,
                'message': f'Código de verificação enviado para {phone_number}'
            }
        else:
            return {
                'success': False,
                'message': 'Erro ao enviar código de verificação'
            }
    
    def confirm_phone_verification(self, verification_id: str, code: str) -> Dict[str, Any]:
        """Confirma verificação do número de telefone"""
        if verification_id not in self.verified_numbers:
            return {
                'success': False,
                'message': 'Verificação não encontrada'
            }
        
        verification = self.verified_numbers[verification_id]
        
        # Verificar se não expirou
        expires_at = datetime.fromisoformat(verification['expires_at'])
        if datetime.now() > expires_at:
            return {
                'success': False,
                'message': 'Código de verificação expirado'
            }
        
        # Verificar código
        if verification['verification_code'] != code:
            return {
                'success': False,
                'message': 'Código de verificação inválido'
            }
        
        # Marcar como verificado
        verification['verified'] = True
        verification['verified_at'] = datetime.now().isoformat()
        
        return {
            'success': True,
            'message': 'Número verificado com sucesso',
            'phone_number': verification['phone_number']
        }
    
    def get_user_phone_config(self, user_id: int) -> Optional[Dict[str, Any]]:
        """Obtém configuração do WhatsApp do usuário"""
        for verification in self.verified_numbers.values():
            if verification['user_id'] == user_id and verification['verified']:
                return {
                    'phone_number': verification['phone_number'],
                    'verified': True,
                    'verified_at': verification.get('verified_at'),
                    'notifications_enabled': True,  # Padrão
                    'billing_reminders': True  # Padrão
                }
        return None
    
    def schedule_payment_reminders(self, user_id: int, subscription_data: Dict[str, Any]) -> Dict[str, Any]:
        """Agenda lembretes de pagamento"""
        phone_config = self.get_user_phone_config(user_id)
        
        if not phone_config or not phone_config.get('billing_reminders'):
            return {
                'success': False,
                'message': 'WhatsApp não configurado ou lembretes desabilitados'
            }
        
        due_date = datetime.fromisoformat(subscription_data['expires_at'])
        
        # Agendar lembretes
        reminders = []
        
        # Lembrete 7 dias antes
        reminder_7d = due_date - timedelta(days=7)
        if reminder_7d > datetime.now():
            reminder_id = self._schedule_reminder(
                user_id, 
                phone_config['phone_number'],
                'payment_reminder_7_days',
                reminder_7d,
                subscription_data
            )
            reminders.append({'type': '7_days', 'id': reminder_id, 'scheduled_for': reminder_7d.isoformat()})
        
        # Lembrete 3 dias antes
        reminder_3d = due_date - timedelta(days=3)
        if reminder_3d > datetime.now():
            reminder_id = self._schedule_reminder(
                user_id,
                phone_config['phone_number'],
                'payment_reminder_3_days',
                reminder_3d,
                subscription_data
            )
            reminders.append({'type': '3_days', 'id': reminder_id, 'scheduled_for': reminder_3d.isoformat()})
        
        # Lembrete 1 dia antes
        reminder_1d = due_date - timedelta(days=1)
        if reminder_1d > datetime.now():
            reminder_id = self._schedule_reminder(
                user_id,
                phone_config['phone_number'],
                'payment_reminder_1_day',
                reminder_1d,
                subscription_data
            )
            reminders.append({'type': '1_day', 'id': reminder_id, 'scheduled_for': reminder_1d.isoformat()})
        
        return {
            'success': True,
            'reminders_scheduled': len(reminders),
            'reminders': reminders
        }
    
    def send_payment_confirmation(self, user_id: int, payment_data: Dict[str, Any]) -> Dict[str, Any]:
        """Envia confirmação de pagamento"""
        phone_config = self.get_user_phone_config(user_id)
        
        if not phone_config:
            return {
                'success': False,
                'message': 'WhatsApp não configurado'
            }
        
        # Preparar dados da mensagem
        message_data = {
            'username': payment_data.get('username', 'Cliente'),
            'amount': f"R$ {payment_data['amount']:.2f}",
            'plan_name': payment_data.get('plan_name', 'Plano'),
            'next_due_date': payment_data.get('next_due_date', 'A definir')
        }
        
        # Enviar mensagem
        result = self._send_template_message(
            phone_config['phone_number'],
            'payment_confirmation',
            message_data
        )
        
        return result
    
    def send_overdue_notice(self, user_id: int, subscription_data: Dict[str, Any]) -> Dict[str, Any]:
        """Envia aviso de pagamento em atraso"""
        phone_config = self.get_user_phone_config(user_id)
        
        if not phone_config:
            return {
                'success': False,
                'message': 'WhatsApp não configurado'
            }
        
        # Calcular dias em atraso
        due_date = datetime.fromisoformat(subscription_data['expires_at'])
        overdue_days = (datetime.now() - due_date).days
        
        # Preparar dados da mensagem
        message_data = {
            'username': subscription_data.get('username', 'Cliente'),
            'plan_name': subscription_data.get('plan_name', 'Plano'),
            'overdue_days': str(overdue_days)
        }
        
        # Enviar mensagem
        result = self._send_template_message(
            phone_config['phone_number'],
            'payment_overdue',
            message_data
        )
        
        return result
    
    def send_test_message(self, user_id: int) -> Dict[str, Any]:
        """Envia mensagem de teste"""
        phone_config = self.get_user_phone_config(user_id)
        
        if not phone_config:
            return {
                'success': False,
                'message': 'WhatsApp não configurado'
            }
        
        # Enviar mensagem simples
        message = "🤖 Esta é uma mensagem de teste da Video AI Platform! Seu WhatsApp está configurado corretamente. ✅"
        
        result = self._send_text_message(phone_config['phone_number'], message)
        
        return result
    
    def get_message_history(self, user_id: int, limit: int = 20) -> List[Dict[str, Any]]:
        """Obtém histórico de mensagens do usuário"""
        user_messages = []
        
        for message in self.message_history.values():
            if message['user_id'] == user_id:
                user_messages.append(message)
        
        # Ordenar por data (mais recentes primeiro)
        user_messages.sort(key=lambda x: x['sent_at'], reverse=True)
        
        return user_messages[:limit]
    
    def _validate_phone_number(self, phone_number: str) -> bool:
        """Valida formato do número de telefone"""
        # Remover caracteres não numéricos
        clean_number = re.sub(r'[^\d+]', '', phone_number)
        
        # Verificar se tem formato válido (brasileiro)
        if clean_number.startswith('+55'):
            return len(clean_number) == 14  # +55 + 11 dígitos
        elif clean_number.startswith('55'):
            return len(clean_number) == 13  # 55 + 11 dígitos
        else:
            return len(clean_number) == 11  # 11 dígitos
    
    def _send_verification_code(self, phone_number: str, code: str) -> Dict[str, Any]:
        """Envia código de verificação via WhatsApp"""
        message = f"🔐 Seu código de verificação da Video AI Platform é: *{code}*\n\nEste código expira em 10 minutos."
        
        return self._send_text_message(phone_number, message)
    
    def _send_text_message(self, phone_number: str, message: str) -> Dict[str, Any]:
        """Envia mensagem de texto simples"""
        # Simular envio de mensagem
        message_id = str(uuid.uuid4())
        
        # Simular sucesso/falha (95% de sucesso)
        success = random.random() > 0.05
        
        # Registrar no histórico
        self.message_history[message_id] = {
            'message_id': message_id,
            'user_id': None,  # Será preenchido pelo contexto
            'phone_number': phone_number,
            'message_type': 'text',
            'content': message,
            'status': 'sent' if success else 'failed',
            'sent_at': datetime.now().isoformat()
        }
        
        if success:
            return {
                'success': True,
                'message_id': message_id,
                'message': 'Mensagem enviada com sucesso'
            }
        else:
            return {
                'success': False,
                'message': 'Erro ao enviar mensagem'
            }
    
    def _send_template_message(self, phone_number: str, template_name: str, 
                              parameters: Dict[str, str]) -> Dict[str, Any]:
        """Envia mensagem usando template"""
        # Simular envio de template
        message_id = str(uuid.uuid4())
        
        # Simular sucesso/falha (95% de sucesso)
        success = random.random() > 0.05
        
        # Registrar no histórico
        self.message_history[message_id] = {
            'message_id': message_id,
            'user_id': None,  # Será preenchido pelo contexto
            'phone_number': phone_number,
            'message_type': 'template',
            'template_name': template_name,
            'parameters': parameters,
            'status': 'sent' if success else 'failed',
            'sent_at': datetime.now().isoformat()
        }
        
        if success:
            return {
                'success': True,
                'message_id': message_id,
                'message': 'Mensagem enviada com sucesso'
            }
        else:
            return {
                'success': False,
                'message': 'Erro ao enviar mensagem'
            }
    
    def _schedule_reminder(self, user_id: int, phone_number: str, template_name: str,
                          schedule_time: datetime, subscription_data: Dict[str, Any]) -> str:
        """Agenda um lembrete"""
        reminder_id = str(uuid.uuid4())
        
        self.scheduled_messages[reminder_id] = {
            'reminder_id': reminder_id,
            'user_id': user_id,
            'phone_number': phone_number,
            'template_name': template_name,
            'subscription_data': subscription_data,
            'scheduled_for': schedule_time.isoformat(),
            'status': 'scheduled',
            'created_at': datetime.now().isoformat()
        }
        
        return reminder_id
    
    def process_scheduled_messages(self):
        """Processa mensagens agendadas (seria executado por um cron job)"""
        now = datetime.now()
        
        for reminder_id, reminder in list(self.scheduled_messages.items()):
            if reminder['status'] == 'scheduled':
                scheduled_time = datetime.fromisoformat(reminder['scheduled_for'])
                
                if now >= scheduled_time:
                    # Enviar mensagem
                    result = self._send_template_message(
                        reminder['phone_number'],
                        reminder['template_name'],
                        reminder['subscription_data']
                    )
                    
                    # Atualizar status
                    reminder['status'] = 'sent' if result['success'] else 'failed'
                    reminder['sent_at'] = now.isoformat()
                    
                    if result['success']:
                        reminder['message_id'] = result['message_id']

# Instância global do serviço
whatsapp_service = WhatsAppService()

