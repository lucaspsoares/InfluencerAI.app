import uuid
import json
import time
import random
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional
import requests
from urllib.parse import urlencode

class SocialMediaService:
    """Serviço para integração com redes sociais (Facebook, TikTok, YouTube)"""
    
    def __init__(self):
        self.connected_accounts = {}
        self.post_queue = {}
        self.published_posts = {}
        
        # Configurações simuladas das APIs
        self.platform_configs = {
            'facebook': {
                'api_base': 'https://graph.facebook.com/v18.0',
                'required_scopes': ['pages_manage_posts', 'pages_read_engagement'],
                'max_video_size': 4000000000,  # 4GB
                'supported_formats': ['mp4', 'mov', 'avi']
            },
            'youtube': {
                'api_base': 'https://www.googleapis.com/youtube/v3',
                'required_scopes': ['https://www.googleapis.com/auth/youtube.upload'],
                'max_video_size': 137438953472,  # 128GB
                'supported_formats': ['mp4', 'mov', 'avi', 'wmv', 'flv', 'webm']
            },
            'tiktok': {
                'api_base': 'https://open-api.tiktok.com',
                'required_scopes': ['video.upload', 'video.publish'],
                'max_video_size': 287762808,  # 274MB
                'supported_formats': ['mp4', 'mov']
            }
        }
    
    def get_auth_url(self, platform: str, user_id: int, redirect_uri: str) -> Dict[str, Any]:
        """Gera URL de autenticação para conectar conta da rede social"""
        if platform not in self.platform_configs:
            return {
                'success': False,
                'message': 'Plataforma não suportada'
            }
        
        # Gerar state para segurança
        state = f"{user_id}_{platform}_{uuid.uuid4()}"
        
        # URLs simuladas de autenticação
        auth_urls = {
            'facebook': f"https://www.facebook.com/v18.0/dialog/oauth?client_id=123456&redirect_uri={redirect_uri}&scope=pages_manage_posts,pages_read_engagement&state={state}",
            'youtube': f"https://accounts.google.com/oauth2/auth?client_id=123456&redirect_uri={redirect_uri}&scope=https://www.googleapis.com/auth/youtube.upload&response_type=code&state={state}",
            'tiktok': f"https://www.tiktok.com/auth/authorize?client_key=123456&redirect_uri={redirect_uri}&scope=video.upload,video.publish&response_type=code&state={state}"
        }
        
        return {
            'success': True,
            'auth_url': auth_urls[platform],
            'state': state
        }
    
    def connect_account(self, platform: str, user_id: int, auth_code: str, state: str) -> Dict[str, Any]:
        """Conecta conta da rede social usando código de autorização"""
        if platform not in self.platform_configs:
            return {
                'success': False,
                'message': 'Plataforma não suportada'
            }
        
        # Simular troca do código por token de acesso
        access_token = f"token_{platform}_{user_id}_{uuid.uuid4()}"
        
        # Simular obtenção de informações da conta
        account_info = self._get_mock_account_info(platform, user_id)
        
        # Armazenar conexão
        account_key = f"{user_id}_{platform}"
        self.connected_accounts[account_key] = {
            'user_id': user_id,
            'platform': platform,
            'access_token': access_token,
            'account_info': account_info,
            'connected_at': datetime.now().isoformat(),
            'expires_at': (datetime.now() + timedelta(days=60)).isoformat(),
            'is_active': True
        }
        
        return {
            'success': True,
            'account': account_info,
            'message': f'Conta {platform} conectada com sucesso'
        }
    
    def get_connected_accounts(self, user_id: int) -> List[Dict[str, Any]]:
        """Obtém contas conectadas do usuário"""
        accounts = []
        
        for key, account in self.connected_accounts.items():
            if account['user_id'] == user_id and account['is_active']:
                accounts.append({
                    'platform': account['platform'],
                    'account_info': account['account_info'],
                    'connected_at': account['connected_at'],
                    'expires_at': account['expires_at']
                })
        
        return accounts
    
    def disconnect_account(self, user_id: int, platform: str) -> Dict[str, Any]:
        """Desconecta conta da rede social"""
        account_key = f"{user_id}_{platform}"
        
        if account_key not in self.connected_accounts:
            return {
                'success': False,
                'message': 'Conta não encontrada'
            }
        
        # Marcar como inativa
        self.connected_accounts[account_key]['is_active'] = False
        
        return {
            'success': True,
            'message': f'Conta {platform} desconectada com sucesso'
        }
    
    def schedule_post(self, user_id: int, platforms: List[str], content: Dict[str, Any], 
                     schedule_time: Optional[str] = None) -> Dict[str, Any]:
        """Agenda publicação em redes sociais"""
        post_id = str(uuid.uuid4())
        
        # Validar plataformas
        invalid_platforms = [p for p in platforms if p not in self.platform_configs]
        if invalid_platforms:
            return {
                'success': False,
                'message': f'Plataformas inválidas: {", ".join(invalid_platforms)}'
            }
        
        # Verificar se usuário tem contas conectadas
        connected_platforms = []
        for platform in platforms:
            account_key = f"{user_id}_{platform}"
            if account_key in self.connected_accounts and self.connected_accounts[account_key]['is_active']:
                connected_platforms.append(platform)
        
        if not connected_platforms:
            return {
                'success': False,
                'message': 'Nenhuma conta conectada para as plataformas selecionadas'
            }
        
        # Criar post na fila
        post_data = {
            'post_id': post_id,
            'user_id': user_id,
            'platforms': connected_platforms,
            'content': content,
            'schedule_time': schedule_time or datetime.now().isoformat(),
            'status': 'scheduled' if schedule_time else 'pending',
            'created_at': datetime.now().isoformat(),
            'results': {}
        }
        
        self.post_queue[post_id] = post_data
        
        # Se não tem agendamento, publicar imediatamente
        if not schedule_time:
            self._publish_post(post_id)
        
        return {
            'success': True,
            'post_id': post_id,
            'platforms': connected_platforms,
            'message': 'Post agendado com sucesso' if schedule_time else 'Post sendo publicado'
        }
    
    def publish_video_clip(self, user_id: int, video_path: str, platforms: List[str], 
                          caption: str, tags: List[str] = None) -> Dict[str, Any]:
        """Publica clipe de vídeo nas redes sociais"""
        content = {
            'type': 'video',
            'video_path': video_path,
            'caption': caption,
            'tags': tags or [],
            'with_subtitles': True
        }
        
        return self.schedule_post(user_id, platforms, content)
    
    def get_post_status(self, post_id: str) -> Optional[Dict[str, Any]]:
        """Obtém status de uma publicação"""
        if post_id in self.post_queue:
            return self.post_queue[post_id]
        elif post_id in self.published_posts:
            return self.published_posts[post_id]
        return None
    
    def get_user_posts(self, user_id: int, limit: int = 20) -> List[Dict[str, Any]]:
        """Obtém posts do usuário"""
        user_posts = []
        
        # Posts na fila
        for post in self.post_queue.values():
            if post['user_id'] == user_id:
                user_posts.append(post)
        
        # Posts publicados
        for post in self.published_posts.values():
            if post['user_id'] == user_id:
                user_posts.append(post)
        
        # Ordenar por data de criação (mais recentes primeiro)
        user_posts.sort(key=lambda x: x['created_at'], reverse=True)
        
        return user_posts[:limit]
    
    def get_analytics(self, user_id: int, platform: str, days: int = 30) -> Dict[str, Any]:
        """Obtém analytics das publicações"""
        # Simular dados de analytics
        return {
            'platform': platform,
            'period_days': days,
            'total_posts': random.randint(5, 25),
            'total_views': random.randint(1000, 50000),
            'total_likes': random.randint(100, 5000),
            'total_shares': random.randint(10, 500),
            'total_comments': random.randint(20, 800),
            'engagement_rate': round(random.uniform(2.5, 8.5), 2),
            'top_performing_post': {
                'id': str(uuid.uuid4()),
                'caption': 'Vídeo mais popular do período',
                'views': random.randint(5000, 20000),
                'likes': random.randint(500, 2000),
                'engagement_rate': round(random.uniform(5.0, 12.0), 2)
            }
        }
    
    def _publish_post(self, post_id: str):
        """Publica post nas redes sociais (simulado)"""
        if post_id not in self.post_queue:
            return
        
        post = self.post_queue[post_id]
        post['status'] = 'publishing'
        
        # Simular publicação em cada plataforma
        for platform in post['platforms']:
            try:
                result = self._simulate_platform_publish(platform, post['content'])
                post['results'][platform] = result
            except Exception as e:
                post['results'][platform] = {
                    'success': False,
                    'error': str(e)
                }
        
        # Verificar se todas as publicações foram bem-sucedidas
        all_success = all(result.get('success', False) for result in post['results'].values())
        
        post['status'] = 'published' if all_success else 'partial_failure'
        post['published_at'] = datetime.now().isoformat()
        
        # Mover para posts publicados
        self.published_posts[post_id] = post
        del self.post_queue[post_id]
    
    def _simulate_platform_publish(self, platform: str, content: Dict[str, Any]) -> Dict[str, Any]:
        """Simula publicação em uma plataforma específica"""
        # Simular tempo de upload
        time.sleep(random.uniform(0.5, 2.0))
        
        # Simular sucesso/falha (90% de sucesso)
        success = random.random() > 0.1
        
        if success:
            return {
                'success': True,
                'platform_post_id': f"{platform}_{uuid.uuid4()}",
                'url': f"https://{platform}.com/post/{uuid.uuid4()}",
                'published_at': datetime.now().isoformat()
            }
        else:
            return {
                'success': False,
                'error': f'Erro simulado na publicação no {platform}'
            }
    
    def _get_mock_account_info(self, platform: str, user_id: int) -> Dict[str, Any]:
        """Gera informações simuladas da conta"""
        account_names = {
            'facebook': f'Página Facebook {user_id}',
            'youtube': f'Canal YouTube {user_id}',
            'tiktok': f'@usuario_tiktok_{user_id}'
        }
        
        return {
            'platform': platform,
            'account_id': f"{platform}_{user_id}",
            'name': account_names[platform],
            'username': f"user_{platform}_{user_id}",
            'followers': random.randint(100, 10000),
            'verified': random.choice([True, False]),
            'profile_picture': f"https://example.com/avatar_{user_id}.jpg"
        }

# Instância global do serviço
social_media_service = SocialMediaService()

